module Xcodeproj
  require 'pathname'

  # 设置引用头文件位置
  def self.basePath
     File::join('/Users', `whoami`.chomp, '/Library/ModelFactory/')
#    File::join('/Users', `whoami`.chomp, 'RubyCode/RubyTest/')
  end

  # 追加所有的引用头
  $:<< Xcodeproj.basePath + 'gems/xcodeproj-0.24.2/lib'
  $:<< Xcodeproj.basePath + 'gems/i18n-0.7.0/lib'
  $:<< Xcodeproj.basePath + 'gems/activesupport-4.2.1/lib'
  $:<< Xcodeproj.basePath + 'gems/thread_safe-0.3.5/lib'

  puts '_______________________'
  puts $:
  puts '以上为脚本执行的引用包路径'
  class PlainInformative < StandardError
  end

  class Informative < PlainInformative
    def message
      super !~ /\[!\]/ ? "[!] #{super}\n".red : super
    end
  end

  require 'xcodeproj/user_interface'

  autoload :Command,          'xcodeproj/command'
  autoload :Config,           'xcodeproj/config'
  autoload :Constants,        'xcodeproj/constants'
  autoload :Differ,           'xcodeproj/differ'
  autoload :Helper,           'xcodeproj/helper'
  autoload :PlistHelper,      'xcodeproj/plist_helper'
  autoload :Project,          'xcodeproj/project'
  autoload :Workspace,        'xcodeproj/workspace'
  autoload :XCScheme,         'xcodeproj/scheme'
  autoload :XcodebuildHelper, 'xcodeproj/xcodebuild_helper'
end

module Xcodeproj
  # The version of the xcodeproj gem.
  #
  VERSION = '0.24.2' unless defined? Xcodeproj::VERSION
end
